import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Calculator, TrendingUp, Award, ChevronsDown, Loader2 } from 'lucide-react';
import { Toaster } from '@/components/ui/toaster';
import { toast } from '@/components/ui/use-toast';
import { Button } from '@/components/ui/button';
import SolarForm from '@/components/SolarForm';
import ResultsDisplay from '@/components/ResultsDisplay';
import DepartmentList from '@/components/DepartmentList';
import { supabase } from '@/lib/customSupabaseClient';

function App() {
  const [currentStep, setCurrentStep] = useState('form');
  const [userInput, setUserInput] = useState(null);
  const [recommendations, setRecommendations] = useState(null);
  const [loading, setLoading] = useState(true);
  const [dbData, setDbData] = useState({ departments: [], panels: [] });

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const { data: departments, error: deptError } = await supabase.from('departments').select('*');
        if (deptError) throw deptError;

        const { data: panels, error: panelError } = await supabase.from('panels').select('*');
        if (panelError) throw panelError;

        setDbData({ departments, panels });
      } catch (error) {
        toast({
          title: "Error al cargar datos",
          description: "No se pudo conectar con la base de datos. Usando datos de respaldo.",
          variant: "destructive",
        });
        console.error("Error fetching from Supabase:", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const handleFormSubmit = (formData) => {
    setUserInput(formData);
    
    const calculatedRecommendations = calculateRecommendations(formData);
    setRecommendations(calculatedRecommendations);
    setCurrentStep('results');
    
    toast({
      title: "¡Cálculo completado! ☀️",
      description: "Hemos encontrado las mejores opciones de paneles solares para ti.",
      variant: "success",
    });
  };

  const calculateRecommendations = (data) => {
    const { department, city, area, consumption } = data;
    
    const departmentData = dbData.departments.find(d => d.name === department);
    const radiation = departmentData ? departmentData.solar_radiation : 4.5;
    
    const monthlyConsumption = parseFloat(consumption);
    const availableArea = parseFloat(area);

    const panels = dbData.panels;
    if (!panels || panels.length === 0) {
        toast({
            title: "Error",
            description: "No se encontraron paneles en la base de datos.",
            variant: "destructive"
        });
        return null;
    }

    const dailyConsumption = monthlyConsumption / 30;
    const requiredPower = (dailyConsumption / radiation) * 1000;

    let recommendations = panels.map(panel => {
      const panelsNeeded = Math.ceil(requiredPower / panel.power);
      const totalArea = panelsNeeded * panel.area;
      const totalCost = panelsNeeded * panel.price;
      const totalPower = panelsNeeded * panel.power;
      const monthlyGeneration = (totalPower * radiation * 30) / 1000;
      const monthlySavings = Math.min(monthlyGeneration * 650, monthlyConsumption * 650);
      const paybackYears = totalCost > 0 && monthlySavings > 0 ? totalCost / (monthlySavings * 12) : Infinity;
      const fitsInArea = totalArea <= availableArea;

      return {
        ...panel, panelsNeeded, totalArea, totalCost, totalPower,
        monthlyGeneration, monthlySavings, paybackYears, fitsInArea,
        score: calculateScore(panel, fitsInArea, paybackYears, panel.efficiency)
      };
    });

    recommendations = recommendations.filter(r => r.fitsInArea).sort((a, b) => b.score - a.score);
    
    if (recommendations.length > 0) {
        recommendations[0].recommended = true;
    }

    return {
      userLocation: `${city}, ${department}`, solarRadiation: radiation,
      recommendations: recommendations.slice(0, 9),
      totalConsumption: monthlyConsumption, availableArea
    };
  };

  const calculateScore = (panel, fitsInArea, paybackYears, efficiency) => {
    if (!fitsInArea) return 0;
    let score = 0;
    score += efficiency * 2;
    if (paybackYears !== Infinity) {
        score += (10 - paybackYears) * 5;
    }
    score += panel.warranty;
    return Math.max(0, score);
  };

  const resetCalculator = () => {
    setCurrentStep('form');
    setUserInput(null);
    setRecommendations(null);
  };
  
  const scrollToCalculator = () => {
    document.getElementById('calculator-section').scrollIntoView({ behavior: 'smooth' });
  };

  if (loading) {
    return (
      <div className="min-h-screen solar-pattern flex flex-col items-center justify-center text-white">
        <Loader2 className="w-16 h-16 animate-spin text-yellow-400 mb-4" />
        <p className="text-xl">Conectando con el sol...</p>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>SolarApp - Encuentra tu Panel Solar Perfecto</title>
        <meta name="description" content="Descubre el panel solar más eficiente y económico para tu hogar o empresa. Cálculos personalizados según tu ubicación y consumo energético." />
      </Helmet>
      
      <main>
        <AnimatePresence mode="wait">
          {currentStep === 'form' && (
            <motion.div
              key="form-content"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
            >
              <div className="relative h-[700px] flex items-center justify-center text-center overflow-hidden">
                <video
                  autoPlay
                  loop
                  muted
                  playsInline
                  className="absolute z-0 w-auto min-w-full min-h-full max-w-none"
                  style={{ objectFit: 'cover', width: '100%', height: '100%' }}
                >
                  <source src="https://gljsiglclwgxaclbnvne.supabase.co/storage/v1/object/public/videos//Secuencia%2001-1.mp4" type="video/mp4" />
                  Tu navegador no soporta el video.
                </video>
                <div className="absolute inset-0 bg-black/60"></div>
                <div className="relative z-10 px-4">
                  <motion.h1 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.7, delay: 0.2 }}
                    className="text-4xl md:text-6xl font-extrabold text-white drop-shadow-lg mt-4"
                  >
                    Tu Futuro Energético Comienza Aquí
                  </motion.h1>
                  <motion.p 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.7, delay: 0.4 }}
                    className="text-xl md:text-2xl text-gray-200 max-w-3xl mx-auto mt-6 drop-shadow-md"
                  >
                    Encuentra el panel solar perfecto para tu hogar o empresa.
                  </motion.p>
                   <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.7, delay: 0.6 }}
                    className="mt-10"
                  >
                    <Button onClick={scrollToCalculator} size="lg" className="solar-gradient text-white font-bold text-lg rounded-full px-8 py-6 transition-transform hover:scale-105">
                      <ChevronsDown className="w-6 h-6 mr-3 animate-bounce" />
                      Comenzar Cálculo
                    </Button>
                  </motion.div>
                </div>
              </div>
              
              <div id="calculator-section" className="container mx-auto px-4 pt-16">
                <SolarForm onSubmit={handleFormSubmit} departments={dbData.departments.map(d => d.name)} />
              </div>

              <section className="container mx-auto px-4 py-16">
                <motion.div
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 0.3 }}
                  className="text-center mb-12"
                >
                  <h2 className="text-3xl md:text-4xl font-bold mb-4">
                    ¿Por qué elegir SolarApp?
                  </h2>
                  <p className="text-xl text-gray-300 max-w-2xl mx-auto">
                    La herramienta más completa para tomar la mejor decisión en energía solar
                  </p>
                </motion.div>

                <div className="grid md:grid-cols-3 gap-8">
                  {[
                    { icon: Calculator, title: 'Cálculos Precisos', description: 'Algoritmos avanzados que consideran radiación solar, consumo y área disponible' },
                    { icon: TrendingUp, title: 'ROI Garantizado', description: 'Proyecciones reales de ahorro y tiempo de retorno de inversión' },
                    { icon: Award, title: 'Recomendaciones Expertas', description: 'Comparación inteligente entre diferentes tipos y marcas de paneles' }
                  ].map((feature, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, y: 30 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ duration: 0.6, delay: 0.5 + index * 0.1 }}
                      className="solar-card rounded-2xl p-8 text-center hover:solar-glow transition-all duration-300"
                    >
                      <div className="solar-gradient p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                        <feature.icon className="w-8 h-8 text-white" />
                      </div>
                      <h3 className="text-xl font-bold mb-4">{feature.title}</h3>
                      <p className="text-gray-300">{feature.description}</p>
                    </motion.div>
                  ))}
                </div>
              </section>

              <DepartmentList departments={dbData.departments} />

            </motion.div>
          )}

          {currentStep === 'results' && recommendations && (
            <motion.div
              key="results"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -50 }}
              transition={{ duration: 0.5 }}
              className="container mx-auto px-4 py-8"
            >
              <ResultsDisplay 
                recommendations={recommendations}
                userInput={userInput}
                onReset={resetCalculator}
                fullResults={recommendations}
              />
            </motion.div>
          )}
        </AnimatePresence>
        <Toaster />
      </main>
    </>
  );
}

export default App;