import React from 'react';
import { motion } from 'framer-motion';
import { MapPin, Sun, Maximize, Zap, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import PanelComparison from '@/components/PanelComparison';

const ResultsDisplay = ({ recommendations, userInput, onReset, fullResults, isDetailView = false }) => {
  const formatNumber = (num) => new Intl.NumberFormat('es-CO').format(num);

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.7, type: 'spring' }}
    >
      <div className="text-center mb-12">
        <h1 className="text-3xl md:text-4xl font-extrabold mb-4">
          ¡Aquí está tu Plan Solar Personalizado!
        </h1>
        <p className="text-lg text-gray-300 max-w-2xl mx-auto">
          Basado en tus datos, hemos encontrado las soluciones más eficientes para ti.
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        {[
          { icon: MapPin, label: 'Ubicación', value: recommendations.userLocation },
          { icon: Sun, label: 'Radiación Solar', value: `${recommendations.solarRadiation} kWh/m²/día` },
          { icon: Maximize, label: 'Área Disponible', value: `${formatNumber(recommendations.availableArea)} m²` },
          { icon: Zap, label: 'Consumo Mensual', value: `${formatNumber(recommendations.totalConsumption)} kWh` },
        ].map((item, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.2 + index * 0.1 }}
            className="solar-card rounded-2xl p-6 text-center"
          >
            <item.icon className="w-10 h-10 mx-auto mb-3 text-yellow-400" />
            <p className="text-sm text-gray-400 mb-1">{item.label}</p>
            <p className="text-lg font-bold">{item.value}</p>
          </motion.div>
        ))}
      </div>

      <PanelComparison 
        recommendations={recommendations.recommendations} 
        userInput={userInput}
        fullResults={fullResults}
      />

      {!isDetailView && (
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="text-center mt-12"
        >
          <Button onClick={onReset} variant="outline" size="lg">
            <ArrowLeft className="w-5 h-5 mr-2" />
            Realizar un nuevo cálculo
          </Button>
        </motion.div>
      )}
    </motion.div>
  );
};

export default ResultsDisplay;