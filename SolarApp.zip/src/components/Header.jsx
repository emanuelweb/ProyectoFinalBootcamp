import React from 'react';
import { motion } from 'framer-motion';
import { Link, useNavigate } from 'react-router-dom';
import { Sun, LogIn, UserPlus, User, LogOut, Bookmark } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const Header = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();

  return (
    <header className="bg-black/20 backdrop-blur-sm border-b border-white/10 sticky top-0 z-50">
      <div className="container mx-auto px-4 py-4">
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="flex justify-between items-center"
        >
          <Link to="/" className="flex items-center gap-3">
            <div className="solar-gradient p-2 rounded-lg">
              <Sun className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold">SolarApp</span>
          </Link>
          <div className="flex items-center gap-2 md:gap-4">
            {user ? (
              <>
                <Button variant="ghost" size="icon" onClick={() => navigate('/saved-results')}>
                  <Bookmark className="w-5 h-5 text-yellow-400" />
                </Button>
                <div className="flex items-center gap-2">
                  <User className="w-5 h-5 text-yellow-400" />
                  <span className="text-sm hidden md:block">{user.email}</span>
                </div>
                <Button variant="outline" size="sm" onClick={signOut}>
                  <LogOut className="w-4 h-4 md:mr-2" />
                  <span className="hidden md:inline">Salir</span>
                </Button>
              </>
            ) : (
              <>
                <Button variant="ghost" size="sm" onClick={() => navigate('/auth?mode=login')}>
                  <LogIn className="w-4 h-4 mr-2" />
                  Ingresar
                </Button>
                <Button className="solar-gradient text-white" size="sm" onClick={() => navigate('/auth?mode=register')}>
                  <UserPlus className="w-4 h-4 mr-2" />
                  Registro
                </Button>
              </>
            )}
          </div>
        </motion.div>
      </div>
    </header>
  );
};

export default Header;