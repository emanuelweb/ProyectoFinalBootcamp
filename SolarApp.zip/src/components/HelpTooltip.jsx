import React from 'react';
import { HelpCircle } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

const HelpTooltip = ({ children }) => {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <button type="button" className="ml-2 text-gray-400 hover:text-yellow-400 transition-colors">
          <HelpCircle className="w-4 h-4" />
        </button>
      </DialogTrigger>
      <DialogContent className="solar-card text-white border-yellow-400/50">
        <DialogHeader>
          <DialogTitle className="text-yellow-400 flex items-center gap-2">
            <HelpCircle />
            Información de Ayuda
          </DialogTitle>
        </DialogHeader>
        <div className="mt-4 text-gray-300">
          {children}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default HelpTooltip;