import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Sun, MapPin, Thermometer } from 'lucide-react';

const DepartmentList = () => {
  const [selectedDepartment, setSelectedDepartment] = useState(null);

  const solarRadiationData = {
    'La Guajira': { radiation: 5.5, color: 'hsl(45, 100%, 50%)', level: 'Muy Alto', description: 'Potencial excepcional para generación solar. Ideal para proyectos a gran escala.' },
    'Magdalena': { radiation: 5.3, color: 'hsl(48, 100%, 52%)', level: 'Muy Alto', description: 'Excelente radiación solar, muy favorable para todo tipo de instalaciones.' },
    'Cesar': { radiation: 5.2, color: 'hsl(50, 100%, 53%)', level: 'Alto', description: 'Gran potencial solar, garantizando alta eficiencia y rendimiento.' },
    'Atlántico': { radiation: 5.1, color: 'hsl(52, 100%, 54%)', level: 'Alto', description: 'Condiciones muy buenas para la generación de energía solar.' },
    'Sucre': { radiation: 5.1, color: 'hsl(52, 100%, 54%)', level: 'Alto', description: 'Fuerte radiación que asegura un excelente retorno de inversión.' },
    'Vichada': { radiation: 5.1, color: 'hsl(52, 100%, 54%)', level: 'Alto', description: 'Alto potencial en los llanos orientales, ideal para sistemas aislados.' },
    'Bolívar': { radiation: 5.0, color: 'hsl(54, 100%, 55%)', level: 'Alto', description: 'Radiación solar fuerte y constante, perfecta para sistemas residenciales y comerciales.' },
    'Casanare': { radiation: 5.0, color: 'hsl(54, 100%, 55%)', level: 'Alto', description: 'Excelente recurso solar, ideal para el sector agroindustrial y residencial.' },
    'Córdoba': { radiation: 4.9, color: 'hsl(56, 100%, 56%)', level: 'Alto', description: 'Muy buen nivel de radiación, apto para una generación energética eficiente.' },
    'Arauca': { radiation: 4.9, color: 'hsl(56, 100%, 56%)', level: 'Alto', description: 'Potencial solar significativo, con buen rendimiento durante todo el año.' },
    'Valle del Cauca': { radiation: 4.8, color: 'hsl(58, 100%, 57%)', level: 'Bueno', description: 'Buen nivel de radiación, viable para la mayoría de aplicaciones solares.' },
    'Meta': { radiation: 4.8, color: 'hsl(58, 100%, 57%)', level: 'Bueno', description: 'Condiciones favorables para proyectos solares con buen rendimiento.' },
    'Huila': { radiation: 4.7, color: 'hsl(60, 100%, 58%)', level: 'Bueno', description: 'Potencial solar considerable, especialmente en zonas secas como el desierto de la Tatacoa.' },
    'Cauca': { radiation: 4.6, color: 'hsl(62, 100%, 59%)', level: 'Bueno', description: 'Nivel de radiación adecuado para una generación de energía solar efectiva.' },
    'Norte de Santander': { radiation: 4.6, color: 'hsl(62, 100%, 59%)', level: 'Bueno', description: 'Buen recurso solar, especialmente en las zonas más secas de la región.' },
    'Tolima': { radiation: 4.6, color: 'hsl(62, 100%, 59%)', level: 'Bueno', description: 'Radiación solar adecuada para la implementación de sistemas fotovoltaicos.' },
    'Antioquia': { radiation: 4.5, color: 'hsl(64, 100%, 60%)', level: 'Medio', description: 'Potencial moderado, viable para sistemas residenciales con buena planificación.' },
    'Nariño': { radiation: 4.5, color: 'hsl(64, 100%, 60%)', level: 'Medio', description: 'Nivel de radiación moderado, con mejores condiciones en zonas costeras.' },
    'Boyacá': { radiation: 4.4, color: 'hsl(66, 100%, 61%)', level: 'Medio', description: 'Radiación aceptable, especialmente en zonas de baja altitud.' },
    'Quindío': { radiation: 4.4, color: 'hsl(66, 100%, 61%)', level: 'Medio', description: 'Potencial solar moderado, afectado por la nubosidad de la región cafetera.' },
    'Risaralda': { radiation: 4.4, color: 'hsl(66, 100%, 61%)', level: 'Medio', description: 'Condiciones moderadas, aún viables para autoconsumo residencial.' },
    'Guaviare': { radiation: 4.4, color: 'hsl(66, 100%, 61%)', level: 'Medio', description: 'Potencial medio en la región amazónica, útil para sistemas aislados.' },
    'Santander': { radiation: 4.3, color: 'hsl(68, 100%, 62%)', level: 'Medio', description: 'Radiación moderada, con buen potencial en zonas como el Cañón del Chicamocha.' },
    'Caldas': { radiation: 4.3, color: 'hsl(68, 100%, 62%)', level: 'Medio', description: 'Potencial moderado, similar a otros departamentos del eje cafetero.' },
    'Guainía': { radiation: 4.3, color: 'hsl(68, 100%, 62%)', level: 'Medio', description: 'Nivel de radiación medio, adecuado para comunidades no interconectadas.' },
    'Cundinamarca': { radiation: 4.2, color: 'hsl(70, 100%, 63%)', level: 'Bajo', description: 'Potencial más bajo debido a la altitud y nubosidad de la sabana, requiere paneles de alta eficiencia.' },
    'Caquetá': { radiation: 4.2, color: 'hsl(70, 100%, 63%)', level: 'Bajo', description: 'Radiación limitada por la alta nubosidad y humedad de la región.' },
    'Vaupés': { radiation: 4.2, color: 'hsl(70, 100%, 63%)', level: 'Bajo', description: 'Bajo potencial solar debido a las condiciones selváticas y de alta nubosidad.' },
    'Amazonas': { radiation: 4.1, color: 'hsl(72, 100%, 64%)', level: 'Bajo', description: 'Potencial limitado por la densa selva y la nubosidad constante.' },
    'Putumayo': { radiation: 4.1, color: 'hsl(72, 100%, 64%)', level: 'Bajo', description: 'Baja radiación, los sistemas solares deben ser cuidadosamente dimensionados.' },
    'Chocó': { radiation: 4.0, color: 'hsl(74, 100%, 65%)', level: 'Bajo', description: 'El potencial más bajo del país debido a la alta pluviosidad y nubosidad.' },
    'Archipiélago de San Andrés': { radiation: 5.4, color: 'hsl(46, 100%, 51%)', level: 'Muy Alto', description: 'Excelente potencial caribeño, ideal para reducir costos energéticos en la isla.' },
  };

  const departments = Object.keys(solarRadiationData).sort();
  const selectedData = selectedDepartment ? solarRadiationData[selectedDepartment] : null;

  return (
    <section className="py-16 bg-black/10">
      <div className="container mx-auto px-4">
        <motion.div initial={{ opacity: 0, y: 50 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">Potencial Solar de Colombia</h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Selecciona un departamento para ver su nivel de radiación solar y descubrir su potencial energético.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-5 gap-8 items-start">
          <motion.div initial={{ opacity: 0, x: -50 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.8, delay: 0.2 }} className="lg:col-span-2">
            <div className="solar-card rounded-2xl p-4 max-h-[220px] md:max-h-[450px] overflow-y-auto">
              <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2">
                {departments.map(dept => (
                  <li key={dept}>
                    <button
                      onClick={() => setSelectedDepartment(dept)}
                      onMouseEnter={() => setSelectedDepartment(dept)}
                      className={`w-full text-left p-3 rounded-lg transition-all duration-200 text-sm ${selectedDepartment === dept ? 'bg-yellow-400/20 text-yellow-300' : 'hover:bg-white/10'}`}
                    >
                      {dept}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
          
          <motion.div 
            initial={{ opacity: 0, x: 50 }} 
            animate={{ opacity: 1, x: 0 }} 
            transition={{ duration: 0.8, delay: 0.4 }} 
            className="solar-card rounded-2xl p-8 lg:col-span-3 min-h-[300px] md:min-h-[450px] flex flex-col justify-center sticky top-24"
          >
            {selectedData ? (
              <div className="text-center">
                <MapPin className="w-12 h-12 mx-auto text-yellow-400 mb-4" />
                <h3 className="text-3xl font-bold mb-2">{selectedDepartment}</h3>
                <div className="flex items-center justify-center gap-2 text-lg text-gray-300">
                  <Sun className="w-5 h-5 text-yellow-400" />
                  <span>Radiación Promedio:</span>
                </div>
                <p className="text-5xl font-bold my-4" style={{ color: selectedData.color }}>
                  {selectedData.radiation.toFixed(1)}
                  <span className="text-2xl text-gray-400 ml-2">kWh/m²/día</span>
                </p>
                <div className="flex justify-center items-center gap-3 mb-4">
                    <span className="text-xl font-semibold" style={{ color: selectedData.color }}>{selectedData.level}</span>
                    <Thermometer size={24} style={{ color: selectedData.color }} />
                </div>
                <p className="text-gray-300 max-w-md mx-auto">{selectedData.description}</p>
              </div>
            ) : (
              <div className="text-center text-gray-400">
                <MapPin className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-xl font-semibold">Selecciona un departamento</h3>
                <p>Descubre su potencial solar y qué significa para ti.</p>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default DepartmentList;