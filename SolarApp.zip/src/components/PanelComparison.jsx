import React from 'react';
import { motion } from 'framer-motion';
import { Clock, CheckCircle, Star, TrendingUp, Save, FileDown, FileSpreadsheet, MoreVertical, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { supabase } from '@/lib/customSupabaseClient';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { exportToPDF, exportToExcel } from '@/lib/exportUtils';
import { useNavigate } from 'react-router-dom';

const PanelComparison = ({ recommendations, userInput, fullResults }) => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('es-CO', { style: 'currency', currency: 'COP', minimumFractionDigits: 0 }).format(amount);
  };

  const handleSaveResult = async (panel) => {
    if (!user) {
      toast({
        title: "Inicia sesión para guardar",
        description: "Debes tener una cuenta para guardar tus resultados.",
        action: <Button onClick={() => navigate('/auth?mode=login')}>Ingresar</Button>,
        variant: "destructive"
      });
      return;
    }

    try {
      const { error } = await supabase.from('saved_results').insert({
        user_id: user.id,
        user_input: userInput,
        recommendations: fullResults,
        selected_panel_id: panel.id,
      });

      if (error) throw error;

      toast({
        title: "¡Resultado Guardado! ✅",
        description: "Tu cálculo ha sido guardado en tu perfil.",
        variant: "success"
      });
    } catch (error) {
      toast({
        title: "Error al guardar",
        description: "No se pudo guardar el resultado. Inténtalo de nuevo.",
        variant: "destructive",
      });
      console.error("Error saving result:", error);
    }
  };

  const handleDownloadPDF = (panel) => {
    exportToPDF(panel, userInput, fullResults);
    toast({ title: "Descargando PDF...", description: "Tu reporte se está generando." });
  };

  const handleDownloadExcel = (panel) => {
    exportToExcel(panel, userInput, fullResults);
    toast({ title: "Descargando Excel...", description: "Tu hoja de cálculo se está generando." });
  };

  const getEfficiencyColor = (efficiency) => {
    if (efficiency >= 21) return 'text-green-400';
    if (efficiency >= 19) return 'text-yellow-400';
    return 'text-orange-400';
  };

  const getPaybackColor = (years) => {
    if (years <= 6) return 'text-green-400';
    if (years <= 8) return 'text-yellow-400';
    return 'text-orange-400';
  };

  return (
    <div className="space-y-6">
      <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }} className="text-center">
        <h2 className="text-2xl md:text-3xl font-bold mb-2">Comparación de Paneles Solares</h2>
        <p className="text-gray-300">Hemos seleccionado las mejores opciones que se adaptan a tu espacio y necesidades</p>
      </motion.div>

      <div className="grid gap-6 md:grid-cols-1 lg:grid-cols-3">
        {recommendations.map((panel, index) => (
          <motion.div
            key={panel.id}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: index * 0.1 }}
            className={`panel-card rounded-2xl p-6 relative flex flex-col ${panel.recommended ? 'ring-2 ring-green-400 solar-glow' : ''}`}
          >
            {panel.recommended && (
              <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                <div className="recommended-badge px-4 py-1 rounded-full text-white text-sm font-semibold flex items-center">
                  <Star className="w-4 h-4 mr-1" />
                  RECOMENDADO
                </div>
              </div>
            )}

            <div className="text-center mb-6">
              <div className="w-full aspect-square mb-4">
                <img className="w-full h-full object-cover rounded-lg" alt={`Panel solar ${panel.type}`} src={panel.image_url || "https://images.unsplash.com/flagged/photo-1566838616811-559be2de7f3e"} />
              </div>
              <h3 className="text-xl font-bold mb-1">{panel.name}</h3>
              <p className="text-gray-400">{panel.brand}</p>
              <div className="flex items-center justify-center mt-2">
                <span className="bg-blue-500/20 text-blue-300 px-3 py-1 rounded-full text-sm">{panel.type}</span>
              </div>
            </div>

            <div className="space-y-4 mb-6">
              <div className="flex justify-between items-center"><span className="text-gray-400">Potencia</span><span className="font-semibold">{panel.power}W</span></div>
              <div className="flex justify-between items-center"><span className="text-gray-400">Eficiencia</span><span className={`font-semibold ${getEfficiencyColor(panel.efficiency)}`}>{panel.efficiency}%</span></div>
              <div className="w-full mt-1">
                <div className="efficiency-bar-container">
                    <div className="efficiency-bar" style={{ width: `${(panel.efficiency / 25) * 100}%` }}></div>
                </div>
              </div>
              <div className="flex justify-between items-center pt-2"><span className="text-gray-400">Garantía</span><span className="font-semibold">{panel.warranty} años</span></div>
              <div className="flex justify-between items-center"><span className="text-gray-400">Paneles necesarios</span><span className="font-semibold">{panel.panelsNeeded}</span></div>
              <div className="flex justify-between items-center"><span className="text-gray-400">Área requerida</span><span className="font-semibold">{panel.totalArea.toFixed(1)} m²</span></div>
            </div>

            <div className="bg-black/20 rounded-xl p-4 mb-6">
              <div className="grid grid-cols-2 gap-4 text-center">
                <div><DollarSign className="w-5 h-5 mx-auto mb-1 text-green-400" /><p className="text-xs text-gray-400 mb-1">Inversión Total</p><p className="font-bold text-sm">{formatCurrency(panel.totalCost)}</p></div>
                <div><TrendingUp className="w-5 h-5 mx-auto mb-1 text-blue-400" /><p className="text-xs text-gray-400 mb-1">Ahorro Mensual</p><p className="font-bold text-sm savings-highlight">{formatCurrency(panel.monthlySavings)}</p></div>
              </div>
              <div className="text-center mt-4 pt-4 border-t border-white/10"><Clock className="w-4 h-4 inline mr-1 text-yellow-400" /><span className="text-sm text-gray-400">Retorno de inversión: </span><span className={`font-semibold ${getPaybackColor(panel.paybackYears)}`}>{panel.paybackYears.toFixed(1)} años</span></div>
            </div>

            <div className="mb-6">
              <h4 className="font-semibold mb-3 text-sm">Características:</h4>
              <div className="space-y-2">
                {panel.features && panel.features.map((feature, idx) => (<div key={idx} className="flex items-center text-sm"><CheckCircle className="w-4 h-4 mr-2 text-green-400 flex-shrink-0" /><span className="text-gray-300">{feature}</span></div>))}
              </div>
            </div>
            
            <div className="mt-auto">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button className={`w-full py-3 rounded-xl font-semibold transition-all duration-300 ${panel.recommended ? 'solar-gradient hover:opacity-90 text-white' : 'bg-white/10 hover:bg-white/20 border border-white/20'}`}>
                    <MoreVertical className="w-5 h-5 mr-2" />
                    Acciones
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent className="w-56 bg-gray-800 border-gray-700 text-white">
                  <DropdownMenuItem onClick={() => handleSaveResult(panel)}><Save className="mr-2 h-4 w-4" /><span>Guardar Resultado</span></DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleDownloadPDF(panel)}><FileDown className="mr-2 h-4 w-4" /><span>Descargar PDF</span></DropdownMenuItem>
                  <DropdownMenuItem onClick={() => handleDownloadExcel(panel)}><FileSpreadsheet className="mr-2 h-4 w-4" /><span>Descargar Excel</span></DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </motion.div>
        ))}
      </div>

      {recommendations.length > 0 && (
        <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6, delay: 0.5 }} className="solar-card rounded-2xl p-6">
          <h3 className="text-xl font-bold mb-4 text-center">Resumen Comparativo</h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead><tr className="border-b border-white/20"><th className="text-left py-2">Panel</th><th className="text-center py-2">Eficiencia</th><th className="text-center py-2">Inversión</th><th className="text-center py-2">Ahorro/Mes</th><th className="text-center py-2">ROI</th></tr></thead>
              <tbody>
                {recommendations.map((panel) => (
                  <tr key={panel.id} className="border-b border-white/10">
                    <td className="py-3"><div className="flex items-center">{panel.recommended && <Star className="w-4 h-4 mr-2 text-yellow-400" />}<span className={panel.recommended ? 'font-semibold' : ''}>{panel.name}</span></div></td>
                    <td className={`text-center py-3 ${getEfficiencyColor(panel.efficiency)}`}>{panel.efficiency}%</td>
                    <td className="text-center py-3">{formatCurrency(panel.totalCost)}</td>
                    <td className="text-center py-3 text-green-400">{formatCurrency(panel.monthlySavings)}</td>
                    <td className={`text-center py-3 ${getPaybackColor(panel.paybackYears)}`}>{panel.paybackYears.toFixed(1)} años</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default PanelComparison;