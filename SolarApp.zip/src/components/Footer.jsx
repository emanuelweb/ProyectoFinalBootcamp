import React from 'react';
import { Link } from 'react-router-dom';
import { Sun } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-black/20 backdrop-blur-sm border-t border-white/10 mt-16">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex items-center gap-3">
            <div className="solar-gradient p-2 rounded-lg">
              <Sun className="w-6 h-6 text-white" />
            </div>
            <span className="text-xl font-bold">SolarApp</span>
          </div>
          <div className="flex flex-wrap justify-center items-center gap-x-6 gap-y-4">
            <span className="text-sm text-gray-400 w-full text-center md:w-auto md:text-left">Proyecto para:</span>
            <img src="https://storage.googleapis.com/hostinger-horizons-assets-prod/e90349a8-c587-400e-ab2f-8f77de80d859/59a184665ad4f2b904c6058f9b493aeb.webp" alt="Logo Talento Tech" className="h-8" />
            <img src="https://storage.googleapis.com/hostinger-horizons-assets-prod/e90349a8-c587-400e-ab2f-8f77de80d859/e40db023a2838b45d758cd705529bef1.webp" alt="Logo MinTic" className="h-8" />
          </div>
        </div>
        <div className="text-center text-gray-400 mt-8 pt-4 border-t border-white/10 flex flex-col md:flex-row justify-center items-center gap-x-4 gap-y-2 flex-wrap">
          <p>Transformando el futuro energético de Colombia, un panel a la vez.</p>
          <span className="hidden md:inline">|</span>
          <Link to="/documentation" className="text-yellow-400 hover:text-yellow-300 transition-colors">
            Documentación
          </Link>
          <span className="hidden md:inline">|</span>
          <Link to="/presentation" className="text-yellow-400 hover:text-yellow-300 transition-colors">
            Presentación
          </Link>
          <span className="hidden md:inline">|</span>
          <Link to="/datos" className="text-yellow-400 hover:text-yellow-300 transition-colors">
            Datos
          </Link>
        </div>
      </div>
    </footer>
  );
};

export default Footer;