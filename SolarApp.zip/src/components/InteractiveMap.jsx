import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Sun, MapPin } from 'lucide-react';
import ColombiaMap from '@/components/ColombiaMap.jsx';

const InteractiveMap = () => {
  const [hoveredDepartment, setHoveredDepartment] = useState(null);

  const solarRadiationData = {
    'La Guajira': { radiation: 5.5, color: 'hsl(45, 100%, 50%)' },
    'Magdalena': { radiation: 5.3, color: 'hsl(48, 100%, 52%)' },
    'Cesar': { radiation: 5.2, color: 'hsl(50, 100%, 53%)' },
    'Atlántico': { radiation: 5.1, color: 'hsl(52, 100%, 54%)' },
    'Sucre': { radiation: 5.1, color: 'hsl(52, 100%, 54%)' },
    'Vichada': { radiation: 5.1, color: 'hsl(52, 100%, 54%)' },
    'Bolívar': { radiation: 5.0, color: 'hsl(54, 100%, 55%)' },
    'Casanare': { radiation: 5.0, color: 'hsl(54, 100%, 55%)' },
    'Córdoba': { radiation: 4.9, color: 'hsl(56, 100%, 56%)' },
    'Arauca': { radiation: 4.9, color: 'hsl(56, 100%, 56%)' },
    'Valle del Cauca': { radiation: 4.8, color: 'hsl(58, 100%, 57%)' },
    'Meta': { radiation: 4.8, color: 'hsl(58, 100%, 57%)' },
    'Huila': { radiation: 4.7, color: 'hsl(60, 100%, 58%)' },
    'Cauca': { radiation: 4.6, color: 'hsl(62, 100%, 59%)' },
    'Norte de Santander': { radiation: 4.6, color: 'hsl(62, 100%, 59%)' },
    'Tolima': { radiation: 4.6, color: 'hsl(62, 100%, 59%)' },
    'Antioquia': { radiation: 4.5, color: 'hsl(64, 100%, 60%)' },
    'Nariño': { radiation: 4.5, color: 'hsl(64, 100%, 60%)' },
    'Boyacá': { radiation: 4.4, color: 'hsl(66, 100%, 61%)' },
    'Quindío': { radiation: 4.4, color: 'hsl(66, 100%, 61%)' },
    'Risaralda': { radiation: 4.4, color: 'hsl(66, 100%, 61%)' },
    'Guaviare': { radiation: 4.4, color: 'hsl(66, 100%, 61%)' },
    'Santander': { radiation: 4.3, color: 'hsl(68, 100%, 62%)' },
    'Caldas': { radiation: 4.3, color: 'hsl(68, 100%, 62%)' },
    'Guainía': { radiation: 4.3, color: 'hsl(68, 100%, 62%)' },
    'Cundinamarca': { radiation: 4.2, color: 'hsl(70, 100%, 63%)' },
    'Caquetá': { radiation: 4.2, color: 'hsl(70, 100%, 63%)' },
    'Vaupés': { radiation: 4.2, color: 'hsl(70, 100%, 63%)' },
    'Amazonas': { radiation: 4.1, color: 'hsl(72, 100%, 64%)' },
    'Putumayo': { radiation: 4.1, color: 'hsl(72, 100%, 64%)' },
    'Chocó': { radiation: 4.0, color: 'hsl(74, 100%, 65%)' },
    'Archipiélago de San Andrés': { radiation: 5.4, color: 'hsl(46, 100%, 51%)' },
  };

  return (
    <section className="py-16 bg-black/10">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Potencial Solar de Colombia
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Explora la radiación solar promedio en cada departamento y descubre las zonas con mayor potencial energético.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="lg:col-span-2"
          >
            <ColombiaMap 
              data={solarRadiationData}
              onHover={setHoveredDepartment}
            />
          </motion.div>
          
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="solar-card rounded-2xl p-8 h-full flex flex-col justify-center"
          >
            {hoveredDepartment && solarRadiationData[hoveredDepartment] ? (
              <div className="text-center">
                <MapPin className="w-12 h-12 mx-auto text-yellow-400 mb-4" />
                <h3 className="text-2xl font-bold mb-2">{hoveredDepartment}</h3>
                <div className="flex items-center justify-center gap-2 text-lg text-gray-300">
                  <Sun className="w-5 h-5 text-yellow-400" />
                  <span>Radiación Promedio:</span>
                </div>
                <p className="text-4xl font-bold my-4" style={{ color: solarRadiationData[hoveredDepartment].color }}>
                  {solarRadiationData[hoveredDepartment].radiation.toFixed(1)}
                </p>
                <p className="text-gray-400">kWh/m²/día</p>
                <div className="w-full bg-gray-700 rounded-full h-2.5 mt-6">
                  <div 
                    className="bg-yellow-400 h-2.5 rounded-full" 
                    style={{ 
                      width: `${((solarRadiationData[hoveredDepartment].radiation - 3.5) / 2.5) * 100}%`,
                      background: `linear-gradient(90deg, #6EE7B7, ${solarRadiationData[hoveredDepartment].color})`
                    }}
                  ></div>
                </div>
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>Bajo</span>
                  <span>Alto</span>
                </div>
              </div>
            ) : (
              <div className="text-center text-gray-400">
                <MapPin className="w-12 h-12 mx-auto mb-4" />
                <h3 className="text-xl font-semibold">Pasa el cursor sobre el mapa</h3>
                <p>Descubre el potencial solar de cada departamento.</p>
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default InteractiveMap;