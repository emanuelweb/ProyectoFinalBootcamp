import React from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import { Home, Presentation, User, FileText } from 'lucide-react';
import { useAuth } from '@/contexts/SupabaseAuthContext';

const navItems = [
  { path: '/', icon: Home, label: 'Inicio' },
  { path: '/presentation', icon: Presentation, label: 'Presentación' },
  { path: '/documentation', icon: FileText, label: 'Docs' },
  { path: '/auth', icon: User, label: 'Perfil', auth: true },
];

const BottomNav = () => {
  const { user } = useAuth();
  const location = useLocation();

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-black/50 backdrop-blur-lg border-t border-white/10 z-50">
      <div className="flex justify-around items-center h-16">
        {navItems.map((item) => {
          const path = item.auth ? (user ? '/saved-results' : '/auth?mode=login') : item.path;
          const isActive = location.pathname === path || (item.path === '/' && location.pathname.startsWith('/result'));

          return (
            <NavLink
              key={item.label}
              to={path}
              className={({ isActive: navIsActive }) =>
                `flex flex-col items-center justify-center gap-1 transition-colors duration-200 ${
                  isActive || navIsActive ? 'text-yellow-400' : 'text-gray-400 hover:text-white'
                }`
              }
            >
              <item.icon className="w-6 h-6" />
              <span className="text-xs font-medium">{item.label}</span>
            </NavLink>
          );
        })}
      </div>
    </nav>
  );
};

export default BottomNav;