import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Zap, Plus, Minus, Tv, Refrigerator, Laptop, Lightbulb as LightbulbIcon, Smartphone, Speaker, Wind } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';

const applianceData = {
  tv: { name: 'Televisores', icon: Tv, avgConsumption: 15 },
  refrigerator: { name: 'Neveras', icon: Refrigerator, avgConsumption: 45 },
  laptop: { name: 'Computadores', icon: Laptop, avgConsumption: 10 },
  lightbulb: { name: 'Bombillos (LED)', icon: LightbulbIcon, avgConsumption: 2 },
  smartphone: { name: 'Cargadores Celular', icon: Smartphone, avgConsumption: 0.5 },
  speaker: { name: 'Equipos de Sonido', icon: Speaker, avgConsumption: 5 },
  fan: { name: 'Ventiladores', icon: Wind, avgConsumption: 8 },
};

const ConsumptionCalculator = ({ isOpen, onClose, onCalculate }) => {
  const [appliances, setAppliances] = useState({
    tv: 1,
    refrigerator: 1,
    laptop: 1,
    lightbulb: 10,
    smartphone: 2,
    speaker: 1,
    fan: 1,
  });
  const [hours, setHours] = useState({
    tv: 4,
    refrigerator: 24,
    laptop: 6,
    lightbulb: 5,
    smartphone: 3,
    speaker: 2,
    fan: 8,
  });

  const handleApplianceChange = (appliance, value) => {
    setAppliances(prev => ({ ...prev, [appliance]: Math.max(0, value) }));
  };

  const handleHoursChange = (appliance, value) => {
    setHours(prev => ({ ...prev, [appliance]: value[0] }));
  };

  const calculateTotal = () => {
    let total = 0;
    for (const key in appliances) {
      const baseConsumption = applianceData[key].avgConsumption;
      const count = appliances[key];
      const dailyHours = hours[key];
      
      let factor = 1;
      if (key !== 'refrigerator') {
          // A simple approximation: usage hours vs a 'standard' use of 4 hours for many devices
          factor = dailyHours / 4; 
      }

      total += baseConsumption * count * factor;
    }
    return Math.round(total);
  };

  const totalConsumption = calculateTotal();

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 50 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 50 }}
            transition={{ type: 'spring', stiffness: 300, damping: 30 }}
            className="solar-card rounded-3xl p-8 w-full max-w-2xl max-h-[90vh] overflow-y-auto relative"
            onClick={(e) => e.stopPropagation()}
          >
            <Button variant="ghost" size="icon" className="absolute top-4 right-4 text-gray-400 hover:text-white" onClick={onClose}>
              <X />
            </Button>
            <div className="text-center mb-6">
              <Zap className="w-12 h-12 mx-auto text-yellow-400 mb-4" />
              <h2 className="text-2xl font-bold">Calculadora de Consumo Aproximado</h2>
              <p className="text-gray-400 mt-2">Estima tu consumo mensual según tus electrodomésticos.</p>
            </div>

            <div className="space-y-6">
              {Object.entries(applianceData).map(([key, data]) => (
                <div key={key} className="p-4 rounded-xl bg-white/5 border border-white/10">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <data.icon className="w-6 h-6 text-yellow-400" />
                      <span className="font-semibold">{data.name}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="icon" className="w-8 h-8" onClick={() => handleApplianceChange(key, appliances[key] - 1)}>
                        <Minus className="w-4 h-4" />
                      </Button>
                      <span className="w-10 text-center font-bold text-lg">{appliances[key]}</span>
                      <Button variant="outline" size="icon" className="w-8 h-8" onClick={() => handleApplianceChange(key, appliances[key] + 1)}>
                        <Plus className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                  {key !== 'refrigerator' && (
                    <div className="mt-4">
                      <label className="text-sm text-gray-400">Horas de uso al día: {hours[key]}h</label>
                      <Slider
                        defaultValue={[hours[key]]}
                        max={24}
                        step={1}
                        onValueChange={(value) => handleHoursChange(key, value)}
                        className="mt-2"
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div className="mt-8 pt-6 border-t border-white/10 text-center">
              <p className="text-gray-400">Consumo mensual estimado:</p>
              <p className="text-4xl font-bold text-yellow-400 my-2">{totalConsumption} kWh</p>
              <Button className="mt-4 w-full solar-gradient" onClick={() => onCalculate(totalConsumption)}>
                Usar este valor
              </Button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ConsumptionCalculator;