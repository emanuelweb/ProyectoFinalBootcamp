import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Home, Zap, ArrowRight, HelpCircle, Calculator } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/components/ui/use-toast';
import HelpTooltip from '@/components/HelpTooltip';
import ConsumptionCalculator from '@/components/ConsumptionCalculator';

const SolarForm = ({ onSubmit, departments }) => {
  const [formData, setFormData] = useState({
    department: '',
    city: '',
    area: '',
    consumption: ''
  });
  const [isCalculatorOpen, setIsCalculatorOpen] = useState(false);

  const sortedDepartments = [...(departments || [])].sort();

  const cities = {
    'Antioquia': ['Medellín', 'Bello', 'Itagüí', 'Envigado', 'Rionegro'],
    'Cundinamarca': ['Bogotá', 'Soacha', 'Chía', 'Zipaquirá', 'Facatativá'],
    'Valle del Cauca': ['Cali', 'Palmira', 'Buenaventura', 'Tuluá', 'Cartago'],
    'Atlántico': ['Barranquilla', 'Soledad', 'Malambo', 'Sabanalarga', 'Galapa'],
    'Santander': ['Bucaramanga', 'Floridablanca', 'Girón', 'Piedecuesta', 'Barrancabermeja'],
    'Bolívar': ['Cartagena', 'Magangué', 'Turbaco', 'Arjona', 'El Carmen de Bolívar'],
    'Cesar': ['Valledupar', 'Aguachica', 'Codazzi', 'Bosconia', 'Curumaní'],
    'La Guajira': ['Riohacha', 'Maicao', 'Uribia', 'Manaure', 'Fonseca'],
    'Magdalena': ['Santa Marta', 'Ciénaga', 'Fundación', 'Zona Bananera', 'Aracataca'],
    'Córdoba': ['Montería', 'Cereté', 'Sahagún', 'Lorica', 'Planeta Rica'],
    'Amazonas': ['Leticia', 'Puerto Nariño'],
    'Arauca': ['Arauca', 'Saravena', 'Tame'],
    'Archipiélago de San Andrés': ['San Andrés', 'Providencia'],
    'Boyacá': ['Tunja', 'Duitama', 'Sogamoso'],
    'Caldas': ['Manizales', 'La Dorada', 'Chinchiná'],
    'Caquetá': ['Florencia', 'San Vicente del Caguán'],
    'Casanare': ['Yopal', 'Aguazul', 'Villanueva'],
    'Cauca': ['Popayán', 'Santander de Quilichao'],
    'Chocó': ['Quibdó', 'Istmina'],
    'Guainía': ['Inírida'],
    'Guaviare': ['San José del Guaviare'],
    'Huila': ['Neiva', 'Pitalito', 'Garzón'],
    'Meta': ['Villavicencio', 'Acacías', 'Granada'],
    'Nariño': ['Pasto', 'Tumaco', 'Ipiales'],
    'Norte de Santander': ['Cúcuta', 'Ocaña', 'Pamplona'],
    'Putumayo': ['Mocoa', 'Orito', 'Valle del Guamuez'],
    'Quindío': ['Armenia', 'Calarcá', 'Montenegro'],
    'Risaralda': ['Pereira', 'Dosquebradas', 'Santa Rosa de Cabal'],
    'Sucre': ['Sincelejo', 'Corozal', 'Tolú'],
    'Tolima': ['Ibagué', 'Espinal', 'Melgar'],
    'Vaupés': ['Mitú'],
    'Vichada': ['Puerto Carreño']
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({
      ...prev,
      [field]: value,
      ...(field === 'department' && { city: '' })
    }));
  };

  const handleConsumptionCalculated = (calculatedConsumption) => {
    setFormData(prev => ({ ...prev, consumption: calculatedConsumption }));
    setIsCalculatorOpen(false);
    toast({
      title: "¡Consumo calculado! 💡",
      description: `Se ha estimado un consumo de ${calculatedConsumption} kWh. Puedes ajustarlo si es necesario.`,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.department || !formData.city || !formData.area || !formData.consumption) {
      toast({
        title: "¡Faltan datos! ⚠️",
        description: "Por favor completa todos los campos para continuar.",
        variant: "destructive"
      });
      return;
    }

    if (parseFloat(formData.area) <= 0 || parseFloat(formData.consumption) <= 0) {
      toast({
        title: "¡Valores inválidos! ⚠️",
        description: "El área y consumo deben ser valores positivos.",
        variant: "destructive"
      });
      return;
    }

    onSubmit(formData);
  };

  return (
    <>
      <ConsumptionCalculator
        isOpen={isCalculatorOpen}
        onClose={() => setIsCalculatorOpen(false)}
        onCalculate={handleConsumptionCalculated}
      />
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="max-w-4xl mx-auto"
      >
        <div className="solar-card rounded-3xl p-8 md:p-12">
          <div className="text-center mb-8">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="solar-gradient p-4 rounded-full w-20 h-20 mx-auto mb-6 flex items-center justify-center"
            >
              <Home className="w-10 h-10 text-white" />
            </motion.div>
            <h2 className="text-3xl font-bold mb-4">Calcula tu Sistema Solar</h2>
            <p className="text-gray-300 text-lg">
              Ingresa tus datos y descubre cuánto puedes ahorrar con energía solar
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.3 }}>
                <label className="block text-sm font-semibold mb-3 flex items-center">
                  <MapPin className="w-4 h-4 mr-2 text-yellow-400" />
                  Departamento
                </label>
                <select value={formData.department} onChange={(e) => handleInputChange('department', e.target.value)} className="w-full p-4 rounded-xl bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all">
                  <option value="" className="bg-gray-800">Selecciona tu departamento</option>
                  {sortedDepartments.map(dept => (
                    <option key={dept} value={dept} className="bg-gray-800">{dept}</option>
                  ))}
                </select>
              </motion.div>

              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.5, delay: 0.4 }}>
                <label className="block text-sm font-semibold mb-3 flex items-center">
                  <MapPin className="w-4 h-4 mr-2 text-yellow-400" />
                  Ciudad
                </label>
                <select value={formData.city} onChange={(e) => handleInputChange('city', e.target.value)} disabled={!formData.department} className="w-full p-4 rounded-xl bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all disabled:opacity-50">
                  <option value="" className="bg-gray-800">Selecciona tu ciudad</option>
                  {formData.department && cities[formData.department]?.map(city => (
                    <option key={city} value={city} className="bg-gray-800">{city}</option>
                  ))}
                </select>
              </motion.div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.5 }}>
                <label className="block text-sm font-semibold mb-3 flex items-center">
                  <Home className="w-4 h-4 mr-2 text-yellow-400" />
                  Área disponible (m²)
                  <HelpTooltip>
                    <h4 className="font-bold text-lg mb-2">¿Cómo medir el área disponible?</h4>
                    <p className="text-sm">Mide el largo y ancho del espacio en tu techo, terraza o terreno donde no haya sombras la mayor parte del día. Multiplica estas dos medidas para obtener los metros cuadrados (m²).</p>
                    <p className="text-sm mt-2"><strong>Ejemplo:</strong> Un techo de 5 metros de largo por 4 metros de ancho tiene 20 m² de área disponible.</p>
                  </HelpTooltip>
                </label>
                <input type="number" value={formData.area} onChange={(e) => handleInputChange('area', e.target.value)} placeholder="Ej: 50" min="1" step="0.1" className="w-full p-4 rounded-xl bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all" />
              </motion.div>

              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.6 }}>
                <label className="block text-sm font-semibold mb-3 flex items-center">
                  <Zap className="w-4 h-4 mr-2 text-yellow-400" />
                  Consumo mensual (kWh)
                  <HelpTooltip>
                    <h4 className="font-bold text-lg mb-2">¿Dónde encontrar tu consumo?</h4>
                    <p className="text-sm">Puedes encontrar este valor en tu factura de energía eléctrica. Busca un término como "Consumo del mes" o "Total kWh facturados".</p>
                    <p className="text-sm mt-2"><strong>¿No tienes tu factura a mano?</strong> Usa nuestra calculadora para obtener un estimado.</p>
                  </HelpTooltip>
                </label>
                <div className="relative">
                  <input type="number" value={formData.consumption} onChange={(e) => handleInputChange('consumption', e.target.value)} placeholder="Ej: 300" min="1" className="w-full p-4 rounded-xl bg-white/10 border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-400 focus:border-transparent transition-all" />
                </div>
              </motion.div>
            </div>
            
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.65 }}>
              <Button type="button" variant="outline" className="w-full border-yellow-400/50 text-yellow-300 hover:bg-yellow-400/10 hover:text-yellow-200" onClick={() => setIsCalculatorOpen(true)}>
                <Calculator className="w-5 h-5 mr-3" />
                Calcula un aproximado del Consumo Mensual
              </Button>
            </motion.div>

            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5, delay: 0.7 }} className="pt-4">
              <Button type="submit" className="w-full solar-gradient hover:opacity-90 text-white font-semibold py-4 px-8 rounded-xl text-lg transition-all duration-300 hover:scale-105 hover:shadow-2xl">
                <span className="md:hidden flex items-center justify-center">
                  Calcular <ArrowRight className="w-5 h-5 ml-2" />
                </span>
                <span className="hidden md:flex items-center justify-center">
                  Calcular mi Sistema Solar
                  <ArrowRight className="w-5 h-5 ml-2" />
                </span>
              </Button>
            </motion.div>
          </form>
        </div>
      </motion.div>
    </>
  );
};

export default SolarForm;