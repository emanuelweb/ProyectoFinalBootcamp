import React from 'react';
import ReactDOM from 'react-dom/client';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import App from '@/App';
import Documentation from '@/pages/Documentation';
import Presentation from '@/pages/Presentation';
import AuthPage from '@/pages/AuthPage';
import SavedResultsPage from '@/pages/SavedResultsPage';
import ResultDetailPage from '@/pages/ResultDetailPage';
import DataPage from '@/pages/DataPage';
import MainLayout from '@/layouts/MainLayout';
import '@/index.css';
import { AuthProvider } from '@/contexts/SupabaseAuthContext';

const router = createBrowserRouter([
  {
    path: '/',
    element: <MainLayout />,
    children: [
      {
        index: true,
        element: <App />,
      },
      {
        path: 'documentation',
        element: <Documentation />,
      },
      {
        path: 'presentation',
        element: <Presentation />,
      },
       {
        path: 'auth',
        element: <AuthPage />,
      },
      {
        path: 'saved-results',
        element: <SavedResultsPage />,
      },
      {
        path: 'result/:id',
        element: <ResultDetailPage />,
      },
      {
        path: 'datos',
        element: <DataPage />,
      }
    ],
  },
]);

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <AuthProvider>
      <RouterProvider router={router} />
    </AuthProvider>
  </React.StrictMode>
);