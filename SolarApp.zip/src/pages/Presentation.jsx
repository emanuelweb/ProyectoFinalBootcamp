import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence, useDragControls } from 'framer-motion';
import { Sun, Zap, MapPin, TrendingUp, CheckCircle, ArrowRight, Cpu, DollarSign, Award, ChevronsLeft, ChevronsRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { supabase } from '@/lib/customSupabaseClient';

const slides = [
  { id: 'hero', component: HeroSlide },
  { id: 'problem', component: ProblemSlide },
  { id: 'solution', component: SolutionSlide },
  { id: 'potential', component: SolarMapSlide },
  { id: 'calculator', component: CalculatorSlide },
  { id: 'results', component: ResultsSlide },
  { id: 'comparison', component: ComparisonSlide },
  { id: 'benefits', component: BenefitsSlide },
  { id: 'cta', component: CtaSlide },
];

function HeroSlide({ onNext }) {
  return (
    <div className="h-full flex flex-col items-center justify-center text-center">
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, type: 'spring' }}
        className="solar-gradient p-8 rounded-full mb-8"
      >
        <Sun className="w-24 h-24 text-white" />
      </motion.div>
      <motion.h1
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.7, delay: 0.3 }}
        className="text-5xl md:text-7xl font-extrabold mb-4"
      >
        SolarApp
      </motion.h1>
      <motion.p
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.7, delay: 0.5 }}
        className="text-xl md:text-2xl text-gray-300 mb-10"
      >
        Calcula tu sistema solar ideal
      </motion.p>
      <motion.div
        initial={{ y: 20, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.7, delay: 0.7 }}
      >
        <Button size="lg" className="solar-gradient text-white font-bold text-lg rounded-full px-8 py-6" onClick={onNext}>
          Comenzar Presentación <ArrowRight className="ml-2" />
        </Button>
      </motion.div>
    </div>
  );
}

function ProblemSlide() {
  return (
    <div className="h-full flex flex-col items-center justify-center text-center">
      <h2 className="text-4xl font-bold mb-8">El Desafío Energético</h2>
      <div className="grid md:grid-cols-3 gap-8">
        <motion.div initial={{opacity: 0, y: 50}} animate={{opacity: 1, y: 0}} transition={{delay: 0.2}} className="solar-card p-6 rounded-xl">
          <h3 className="text-2xl font-bold text-yellow-400">99%</h3>
          <p>de la energía solar en Colombia sin aprovechar.</p>
        </motion.div>
        <motion.div initial={{opacity: 0, y: 50}} animate={{opacity: 1, y: 0}} transition={{delay: 0.4}} className="solar-card p-6 rounded-xl">
          <h3 className="text-2xl font-bold text-yellow-400">Complejidad</h3>
          <p>para elegir el panel solar correcto.</p>
        </motion.div>
        <motion.div initial={{opacity: 0, y: 50}} animate={{opacity: 1, y: 0}} transition={{delay: 0.6}} className="solar-card p-6 rounded-xl">
          <h3 className="text-2xl font-bold text-yellow-400">Incertidumbre</h3>
          <p>sobre la inversión y el ahorro real.</p>
        </motion.div>
      </div>
    </div>
  );
}

function SolutionSlide() {
  return (
    <div className="h-full flex flex-col items-center justify-center text-center">
      <h2 className="text-4xl font-bold mb-8">Nuestra Solución: Simple y Potente</h2>
      <div className="grid md:grid-cols-3 gap-8">
        <motion.div initial={{opacity: 0, scale: 0.8}} animate={{opacity: 1, scale: 1}} transition={{delay: 0.2}} className="solar-card p-6 rounded-xl">
          <MapPin className="w-12 h-12 mx-auto text-yellow-400 mb-4" />
          <h3 className="font-bold">1. Ingresa tus Datos</h3>
          <p className="text-sm text-gray-400">Ubicación, área y consumo.</p>
        </motion.div>
        <motion.div initial={{opacity: 0, scale: 0.8}} animate={{opacity: 1, scale: 1}} transition={{delay: 0.4}} className="solar-card p-6 rounded-xl">
          <Cpu className="w-12 h-12 mx-auto text-yellow-400 mb-4" />
          <h3 className="font-bold">2. Analizamos</h3>
          <p className="text-sm text-gray-400">Calculamos tu potencial y necesidades.</p>
        </motion.div>
        <motion.div initial={{opacity: 0, scale: 0.8}} animate={{opacity: 1, scale: 1}} transition={{delay: 0.6}} className="solar-card p-6 rounded-xl">
          <TrendingUp className="w-12 h-12 mx-auto text-yellow-400 mb-4" />
          <h3 className="font-bold">3. Recibes Recomendaciones</h3>
          <p className="text-sm text-gray-400">La mejor opción para ti, clara y fácil.</p>
        </motion.div>
      </div>
    </div>
  );
}

function SolarMapSlide() {
    const [departments, setDepartments] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchDepartments = async () => {
            setLoading(true);
            const { data, error } = await supabase.from('departments').select('name, solar_radiation, color, level').order('solar_radiation', { ascending: false });
            if (!error) {
                setDepartments(data);
            } else {
                console.error("Error fetching departments", error);
            }
            setLoading(false);
        };
        fetchDepartments();
    }, []);

    return (
        <div className="h-full flex flex-col items-center justify-center text-center w-full">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Potencial Solar de Colombia</h2>
            <p className="text-gray-400 mb-6">Radiación promedio en kWh/m²/día.</p>
            <div className="grid md:grid-cols-5 gap-6 w-full max-w-5xl">
                <div className="solar-card rounded-xl p-2 md:col-span-3 flex items-center justify-center">
                    <img src="https://storage.googleapis.com/hostinger-horizons-assets-prod/e90349a8-c587-400e-ab2f-8f77de80d859/b02989c4e1dfffd4cc1992e9edf276da.png" alt="Mapa de Colombia" className="w-full h-auto object-contain max-h-[380px]" />
                </div>
                <div className="solar-card rounded-xl p-4 md:col-span-2 h-[420px] overflow-y-auto">
                    {loading ? <p>Cargando datos...</p> : (
                        <ul className="space-y-2">
                           {departments.map(dept => (
                               <li key={dept.name} className="flex items-center justify-between p-2 rounded-lg bg-white/5">
                                   <div className="flex items-center">
                                       <div className="w-3 h-3 rounded-full mr-3 flex-shrink-0" style={{ backgroundColor: dept.color }}></div>
                                       <span className="font-semibold text-sm">{dept.name}</span>
                                   </div>
                                   <div className="flex items-center gap-2">
                                        <span className="font-bold text-base" style={{ color: dept.color }}>{dept.solar_radiation}</span>
                                        <span className="text-xs px-2 py-0.5 rounded-full text-white" style={{ backgroundColor: dept.color }}>{dept.level}</span>
                                   </div>
                               </li>
                           ))}
                        </ul>
                    )}
                </div>
            </div>
        </div>
    );
}

function CalculatorSlide() {
  return (
    <div className="h-full flex flex-col items-center justify-center text-center">
      <h2 className="text-4xl font-bold mb-8">Calculadora Inteligente</h2>
      <p className="text-gray-400 mb-8">Estima tu consumo mensual fácilmente.</p>
      <div className="solar-card p-8 rounded-xl w-full max-w-md">
        <div className="space-y-4">
          <div className="flex justify-between items-center"><span>Televisores</span><span className="font-bold">2</span></div>
          <div className="flex justify-between items-center"><span>Nevera</span><span className="font-bold">1</span></div>
          <div className="flex justify-between items-center"><span>Computadores</span><span className="font-bold">1</span></div>
          <div className="flex justify-between items-center"><span>Luces LED</span><span className="font-bold">15</span></div>
        </div>
        <div className="mt-8 pt-4 border-t border-white/20">
          <p className="text-gray-400">Consumo estimado:</p>
          <p className="text-3xl font-bold text-yellow-400">250 kWh/mes</p>
        </div>
      </div>
    </div>
  );
}

function ResultsSlide() {
  return (
    <div className="h-full flex flex-col items-center justify-center text-center">
      <h2 className="text-4xl font-bold mb-8">Resultados Personalizados</h2>
      <div className="grid grid-cols-2 gap-6">
        <div className="solar-card p-6 rounded-xl"><Zap className="w-8 h-8 mx-auto text-blue-400 mb-2" /><p className="font-bold text-lg">300 kWh</p><p className="text-sm text-gray-400">Consumo</p></div>
        <div className="solar-card p-6 rounded-xl"><DollarSign className="w-8 h-8 mx-auto text-green-400 mb-2" /><p className="font-bold text-lg">$195,000</p><p className="text-sm text-gray-400">Ahorro/Mes</p></div>
        <div className="solar-card p-6 rounded-xl"><TrendingUp className="w-8 h-8 mx-auto text-yellow-400 mb-2" /><p className="font-bold text-lg">6.5 años</p><p className="text-sm text-gray-400">Retorno Inversión</p></div>
        <div className="solar-card p-6 rounded-xl"><Award className="w-8 h-8 mx-auto text-orange-400 mb-2" /><p className="font-bold text-lg">Panel Pro X</p><p className="text-sm text-gray-400">Recomendado</p></div>
      </div>
    </div>
  );
}

function ComparisonSlide() {
    const data = [
        { name: 'Panel A', eficiencia: 19, precio: 800000, roi: 8 },
        { name: 'Panel B', eficiencia: 21, precio: 1000000, roi: 7 },
        { name: 'Panel C (Pro X)', eficiencia: 22, precio: 1200000, roi: 6.5 },
        { name: 'Panel D', eficiencia: 18, precio: 700000, roi: 9 },
    ];
    return (
        <div className="h-full flex flex-col items-center justify-center text-center">
            <h2 className="text-4xl font-bold mb-8">Comparativa de Paneles</h2>
            <div className="w-full h-[300px] solar-card rounded-xl p-4">
                <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={data}>
                        <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
                        <XAxis dataKey="name" stroke="white" />
                        <YAxis yAxisId="left" orientation="left" stroke="#FFD700" label={{ value: 'Precio (COP)', angle: -90, position: 'insideLeft', fill: '#FFD700' }} />
                        <YAxis yAxisId="right" orientation="right" stroke="#10B981" label={{ value: 'Eficiencia (%)', angle: 90, position: 'insideRight', fill: '#10B981' }} />
                        <Tooltip contentStyle={{ backgroundColor: '#0F172A', border: '1px solid #FFD700' }} />
                        <Legend />
                        <Bar yAxisId="left" dataKey="precio" fill="#FFD700" name="Precio" />
                        <Bar yAxisId="right" dataKey="eficiencia" fill="#10B981" name="Eficiencia" />
                    </BarChart>
                </ResponsiveContainer>
            </div>
        </div>
    );
}

function BenefitsSlide() {
  const benefits = ["Ahorro en tu factura", "Energía limpia y renovable", "Aumenta el valor de tu propiedad", "Bajo mantenimiento"];
  return (
    <div className="h-full flex flex-col items-center justify-center text-center">
      <h2 className="text-4xl font-bold mb-8">Beneficios de la Energía Solar</h2>
      <div className="space-y-4">
        {benefits.map((benefit, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.2 }}
            className="flex items-center text-xl"
          >
            <CheckCircle className="w-6 h-6 mr-4 text-green-400" />
            <span>{benefit}</span>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

function CtaSlide() {
  return (
    <div className="h-full flex flex-col items-center justify-center text-center">
      <motion.h2
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7 }}
        className="text-4xl md:text-5xl font-bold mb-6"
      >
        ¿Listo para dar el paso?
      </motion.h2>
      <motion.p
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, delay: 0.2 }}
        className="text-lg text-gray-300 mb-8 max-w-xl"
      >
        Usa nuestra calculadora gratuita y descubre el potencial solar de tu hogar o negocio hoy mismo.
      </motion.p>
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.7, delay: 0.4, type: 'spring' }}
      >
        <Button size="lg" className="solar-gradient text-white font-bold text-lg rounded-full px-10 py-8" asChild>
          <a href="/">Ir a la Calculadora <ArrowRight className="ml-2" /></a>
        </Button>
      </motion.div>
    </div>
  );
}

const Presentation = () => {
  const [slideIndex, setSlideIndex] = useState(0);
  const dragControls = useDragControls();

  const handleNext = () => {
    setSlideIndex(prev => (prev + 1) % slides.length);
  };

  const handlePrev = () => {
    setSlideIndex(prev => (prev - 1 + slides.length) % slides.length);
  };

  const handleDragEnd = (event, info) => {
    const offset = info.offset.x;
    const velocity = info.velocity.x;

    if (offset < -100 || velocity < -500) {
      handleNext();
    } else if (offset > 100 || velocity > 500) {
      handlePrev();
    }
  };

  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === 'ArrowRight') handleNext();
      if (e.key === 'ArrowLeft') handlePrev();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const CurrentSlide = slides[slideIndex].component;

  return (
    <>
      <Helmet>
        <title>Presentación - SolarApp</title>
        <meta name="description" content="Presentación infográfica animada del proyecto SolarApp." />
      </Helmet>
      <div className="relative w-full h-[calc(100vh-160px)] overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={slideIndex}
            drag="x"
            dragControls={dragControls}
            dragConstraints={{ left: 0, right: 0 }}
            onDragEnd={handleDragEnd}
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -100 }}
            transition={{ duration: 0.5 }}
            className="absolute inset-0 p-8 flex items-center justify-center cursor-grab active:cursor-grabbing"
          >
            <CurrentSlide onNext={handleNext} />
          </motion.div>
        </AnimatePresence>
        
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 md:hidden flex items-center text-white/50 animate-pulse">
            <ChevronsLeft className="w-5 h-5" />
            <span className="text-sm mx-2">Desliza</span>
            <ChevronsRight className="w-5 h-5" />
        </div>

        <div className="absolute bottom-8 md:bottom-12 left-1/2 -translate-x-1/2 hidden md:flex items-center gap-4 presentation-dots">
          <Button variant="outline" onClick={handlePrev}>Anterior</Button>
          <div className="flex gap-2">
            {slides.map((_, i) => (
              <div
                key={i}
                onClick={() => setSlideIndex(i)}
                className={`w-3 h-3 rounded-full cursor-pointer transition-all ${i === slideIndex ? 'bg-yellow-400 scale-125' : 'bg-gray-600'}`}
              />
            ))}
          </div>
          <Button variant="outline" onClick={handleNext}>Siguiente</Button>
        </div>
      </div>
    </>
  );
};

export default Presentation;