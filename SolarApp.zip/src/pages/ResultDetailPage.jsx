import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { Loader2, ArrowLeft } from 'lucide-react';
import { toast } from '@/components/ui/use-toast';
import ResultsDisplay from '@/components/ResultsDisplay';
import { Button } from '@/components/ui/button';

const ResultDetailPage = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      navigate('/auth?mode=login');
      return;
    }

    const fetchResult = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('saved_results')
        .select('*')
        .eq('id', id)
        .eq('user_id', user.id)
        .single();

      if (error || !data) {
        console.error('Error fetching result:', error);
        toast({
          title: "Error",
          description: "No se pudo encontrar el resultado o no tienes permiso para verlo.",
          variant: "destructive",
        });
        navigate('/saved-results');
      } else {
        setResult(data);
      }
      setLoading(false);
    };

    fetchResult();
  }, [id, user, navigate]);

  if (loading) {
    return (
      <div className="flex-grow flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-yellow-400" />
      </div>
    );
  }

  if (!result) {
    return null; 
  }

  return (
    <>
      <Helmet>
        <title>Detalle del Resultado - SolarApp</title>
        <meta name="description" content={`Detalle del cálculo de paneles solares para ${result.user_input.city}.`} />
      </Helmet>
      <div className="container mx-auto px-4 py-8">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Button variant="ghost" asChild className="mb-6">
            <Link to="/saved-results">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Volver a Mis Resultados
            </Link>
          </Button>
          <ResultsDisplay
            recommendations={result.recommendations}
            userInput={result.user_input}
            fullResults={result.recommendations}
            onReset={() => navigate('/')}
            isDetailView={true}
          />
        </motion.div>
      </div>
    </>
  );
};

export default ResultDetailPage;