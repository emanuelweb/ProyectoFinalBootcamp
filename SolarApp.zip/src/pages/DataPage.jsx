import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Sun, Droplets, Map, BarChart2, Zap, Home, Wind, DollarSign, Clock, CheckCircle, Cpu, Globe, Target } from 'lucide-react';
import { Button } from '@/components/ui/button';

const cardVariants = {
  offscreen: { y: 50, opacity: 0 },
  onscreen: {
    y: 0,
    opacity: 1,
    transition: {
      type: 'spring',
      bounce: 0.4,
      duration: 0.8,
    },
  },
};

const InfographicCard = ({ icon: Icon, title, children, color }) => (
  <motion.div
    className="solar-card rounded-2xl p-8 flex flex-col items-center text-center"
    variants={cardVariants}
  >
    <div className={`p-4 rounded-full mb-6 inline-flex`} style={{ backgroundColor: color }}>
      <Icon className="w-8 h-8 text-white" />
    </div>
    <h3 className="text-2xl font-bold mb-4">{title}</h3>
    <div className="text-gray-300 leading-relaxed">{children}</div>
  </motion.div>
);

const DataPage = () => {
  return (
    <>
      <Helmet>
        <title>Datos sobre Energía Solar en Colombia - SolarApp</title>
        <meta name="description" content="Descubre por qué la energía solar es el futuro de Colombia con datos y estadísticas clave." />
      </Helmet>
      <div className="container mx-auto px-4 py-16">
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="text-center mb-16"
        >
          <Sun className="w-16 h-16 mx-auto text-yellow-400 mb-4 animate-spin-slow" />
          <h1 className="text-4xl md:text-5xl font-extrabold">¿Por qué la Energía Solar es el Futuro de Colombia?</h1>
        </motion.div>

        <motion.div 
            className="grid md:grid-cols-1 gap-12"
            initial="offscreen"
            whileInView="onscreen"
            viewport={{ once: true, amount: 0.2 }}
            transition={{ staggerChildren: 0.3 }}
        >
          <InfographicCard icon={Globe} title="Introducción" color="#FF8C00">
            <p>Colombia recibe más sol que muchos países líderes en energía solar, como Alemania. Sin embargo, no lo aprovechamos lo suficiente. ¡Esto está cambiando!</p>
          </InfographicCard>

          <motion.div variants={cardVariants} className="solar-card rounded-2xl p-8">
            <h3 className="text-2xl font-bold mb-6 text-center">Colombia brilla más que Berlín</h3>
            <div className="flex flex-col md:flex-row items-center justify-center gap-8">
              <div className="text-center">
                <p className="text-4xl font-bold text-yellow-400">5.3 <span className="text-xl">kWh/m²/día</span></p>
                <p className="text-gray-400">La Guajira, Colombia</p>
              </div>
              <div className="text-4xl font-bold text-gray-500">vs</div>
              <div className="text-center">
                <p className="text-4xl font-bold text-blue-400">2.8 <span className="text-xl">kWh/m²/día</span></p>
                <p className="text-gray-400">Berlín, Alemania</p>
              </div>
            </div>
            <p className="mt-6 text-center text-gray-300 max-w-2xl mx-auto">Colombia tiene el doble de potencial solar que Berlín, y aún así Alemania lidera en energía solar. Imagina lo que podríamos lograr aquí.</p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <InfographicCard icon={Droplets} title="Limpia y Renovable" color="#10B981">
                <p>No contamina ni se agota.</p>
            </InfographicCard>
            <InfographicCard icon={DollarSign} title="Ahorro en Facturas" color="#10B981">
                <p>Reduce tu gasto eléctrico mes a mes.</p>
            </InfographicCard>
            <InfographicCard icon={Home} title="Más Valor a tu Hogar" color="#10B981">
                <p>Una casa con paneles vale más.</p>
            </InfographicCard>
            <InfographicCard icon={Wind} title="Menos CO₂" color="#10B981">
                <p>Cada hogar solar evita cientos de kilos de emisiones.</p>
            </InfographicCard>
          </div>

          <motion.div variants={cardVariants} className="solar-card rounded-2xl p-8">
             <h3 className="text-2xl font-bold mb-6 text-center">¿Sabías que...?</h3>
             <div className="grid md:grid-cols-2 gap-6">
                <div className="flex items-start gap-4"><CheckCircle className="w-6 h-6 text-yellow-400 mt-1 flex-shrink-0"/><p>Colombia tiene 32 departamentos con potencial solar medio a muy alto.</p></div>
                <div className="flex items-start gap-4"><CheckCircle className="w-6 h-6 text-yellow-400 mt-1 flex-shrink-0"/><p>Incluso ciudades nubladas como Bogotá pueden beneficiarse si se usan paneles eficientes.</p></div>
                <div className="flex items-start gap-4"><CheckCircle className="w-6 h-6 text-yellow-400 mt-1 flex-shrink-0"/><p>Con solo 10 m² de techo libre ya puedes generar energía para tu hogar.</p></div>
                <div className="flex items-start gap-4"><CheckCircle className="w-6 h-6 text-yellow-400 mt-1 flex-shrink-0"/><p>En algunas regiones de Colombia, el retorno de inversión solar es menor a 6 años.</p></div>
             </div>
          </motion.div>
          
          <motion.div variants={cardVariants} className="solar-card rounded-2xl p-8 flex flex-col md:flex-row items-center gap-8">
              <div className="flex-1">
                <h3 className="text-2xl font-bold mb-4">¿Y si no sé cuánto consumo?</h3>
                <p className="text-gray-300 mb-6">Con herramientas modernas, puedes estimar tu consumo en segundos y saber cuántos paneles necesitas sin ser experto.</p>
                <Button asChild className="solar-gradient text-white">
                  <Link to="/">Ir a la Calculadora Solar</Link>
                </Button>
              </div>
              <div className="text-yellow-300">
                <Home className="w-24 h-24" />
              </div>
          </motion.div>
          
          <InfographicCard icon={Target} title="Impacto Ambiental y Social" color="#1E40AF">
            <ul className="list-none space-y-2">
              <li className="flex items-center gap-2 justify-center"><Globe className="w-5 h-5"/>Una tierra más limpia para las nuevas generaciones.</li>
              <li className="flex items-center gap-2 justify-center"><Zap className="w-5 h-5"/>Menor dependencia de combustibles fósiles.</li>
              <li className="flex items-center gap-2 justify-center"><Cpu className="w-5 h-5"/>Más empleos en energía renovable.</li>
              <li className="flex items-center gap-2 justify-center"><CheckCircle className="w-5 h-5"/>Contribuyes a los Objetivos de Desarrollo Sostenible (ODS 7 y 13).</li>
            </ul>
          </InfographicCard>

          <motion.div variants={cardVariants} className="text-center solar-card rounded-2xl p-12">
            <p className="text-3xl font-bold italic mb-8">“El sol sale para todos… ¿y tú? ¿Vas a seguir pagando por algo que podrías generar?”</p>
            <Button asChild size="lg" className="solar-gradient text-white font-bold text-lg">
                <Link to="/">Descubre cómo empezar hoy mismo</Link>
            </Button>
          </motion.div>

        </motion.div>
      </div>
    </>
  );
};

export default DataPage;