import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { BookOpen, Target, Lightbulb, CheckCircle, Settings, Cpu, Database, Code, BarChart, Flag } from 'lucide-react';

const documentationData = [
  {
    icon: BookOpen,
    title: 'Resumen Ejecutivo',
    content: 'Solar App es una aplicación web interactiva que recomienda al usuario el panel solar óptimo según su ubicación, área disponible y consumo mensual. El sistema realiza cálculos técnicos basados en radiación solar por región y compara múltiples opciones de paneles en el mercado. Brinda recomendaciones claras, visuales y basadas en rendimiento, inversión y ahorro energético.',
  },
  {
    icon: Target,
    title: 'Planteamiento del Problema',
    content: 'En Colombia, muchas personas y empresas desconocen qué tipo de panel solar les conviene según su ubicación y necesidades reales. Las decisiones de inversión en energía solar suelen ser complejas por falta de información técnica accesible y personalizada.',
  },
  {
    icon: Lightbulb,
    title: 'Justificación',
    content: 'Solar App empodera a los usuarios con información precisa y personalizada. Reduce las barreras técnicas y económicas para la adopción de energías renovables, contribuyendo así a un desarrollo más sostenible, con beneficios ambientales y económicos.',
  },
  {
    icon: CheckCircle,
    title: 'Objetivo General',
    content: 'Desarrollar una aplicación web que recomiende el panel solar más adecuado para cada usuario, basado en su ubicación geográfica, consumo energético y área disponible, facilitando decisiones de inversión en energía solar.',
  },
  {
    icon: Settings,
    title: 'Objetivos Específicos',
    content: 'Obtener datos de entrada del usuario (departamento, ciudad, área, consumo). Calcular la radiación solar media por departamento. Comparar tipos de paneles solares (eficiencia, potencia, precio, garantía). Calcular retorno de inversión (ROI), número de paneles requeridos y ahorro mensual. Visualizar los resultados en una interfaz clara, con estadísticas y comparativas. Permitir la estimación de consumo mensual usando electrodomésticos.',
  },
  {
    icon: Cpu,
    title: 'Marco Teórico',
    content: 'Energía Solar: Principios básicos, importancia, tipos de paneles (monocristalino, policristalino). Radiación Solar: Medición en kWh/m²/día, su variabilidad geográfica. Consumo Energético: Estimación en kWh según dispositivos comunes. ROI en sistemas fotovoltaicos: Cálculo del retorno de inversión basado en generación y ahorro.',
  },
  {
    icon: Code,
    title: 'Metodología y Tecnologías',
    content: 'Frontend: React, Tailwind CSS, Framer Motion. Backend: Java (Spring Boot) + MySQL. Arquitectura MVC. Base de datos: Catálogo de paneles, radiación por región, registros de usuarios. Herramientas adicionales: Toast UI, Radix UI.',
  },
  {
    icon: BarChart,
    title: 'Resultados Esperados',
    content: 'Recomendación precisa del mejor panel solar. Visualización clara del ahorro e inversión. Mayor accesibilidad a soluciones de energía renovable. Aumento de la conciencia sobre el potencial solar regional.',
  },
  {
    icon: Flag,
    title: 'Conclusiones',
    content: 'Solar App se posiciona como una herramienta educativa y funcional que guía al usuario hacia una transición energética informada y personalizada. Su enfoque visual y técnico convierte información compleja en decisiones claras.',
  },
];

const Documentation = () => {
  const cardVariants = {
    offscreen: {
      y: 50,
      opacity: 0,
    },
    onscreen: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        bounce: 0.4,
        duration: 0.8,
      },
    },
  };

  return (
    <>
      <Helmet>
        <title>Documentación - Solar App</title>
        <meta name="description" content="Documentación técnica y funcional del proyecto Solar App." />
      </Helmet>
      <div className="container mx-auto px-4 py-16">
        <motion.div
          initial={{ opacity: 0, y: -30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7 }}
          className="text-center mb-12"
        >
          <BookOpen className="w-16 h-16 mx-auto text-yellow-400 mb-4" />
          <h1 className="text-4xl md:text-5xl font-extrabold">Documentación del Proyecto</h1>
          <p className="text-xl text-gray-300 mt-4">Solar App: Plataforma de Recomendación de Paneles Solares</p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {documentationData.map((item, index) => (
            <motion.div
              key={index}
              className="solar-card rounded-2xl p-8 flex flex-col"
              initial="offscreen"
              whileInView="onscreen"
              viewport={{ once: true, amount: 0.5 }}
              variants={cardVariants}
            >
              <div className="flex items-center mb-4">
                <div className="solar-gradient p-3 rounded-lg mr-4">
                  <item.icon className="w-6 h-6 text-white" />
                </div>
                <h2 className="text-xl font-bold">{item.title}</h2>
              </div>
              <p className="text-gray-300 leading-relaxed">{item.content}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </>
  );
};

export default Documentation;