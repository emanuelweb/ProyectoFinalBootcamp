import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Mail, Lock, Loader2, Sun } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { toast } from '@/components/ui/use-toast';

const AuthPage = () => {
    const [searchParams, setSearchParams] = useSearchParams();
    const navigate = useNavigate();
    const { signIn, signUp, user } = useAuth();
    
    const [mode, setMode] = useState(searchParams.get('mode') || 'login');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        if(user) {
            navigate('/');
        }
    }, [user, navigate]);

    useEffect(() => {
        const urlMode = searchParams.get('mode');
        if (urlMode && urlMode !== mode) {
            setMode(urlMode);
        }
    }, [searchParams, mode]);

    const handleAuth = async (e) => {
        e.preventDefault();
        setLoading(true);
        const authAction = mode === 'login' ? signIn : signUp;
        const { error } = await authAction(email, password);
        setLoading(false);
        if (!error) {
            toast({
                title: `¡${mode === 'login' ? 'Bienvenido de vuelta' : 'Registro exitoso'}!`,
                description: mode === 'login' ? 'Has iniciado sesión correctamente.' : 'Revisa tu correo para confirmar tu cuenta.',
            });
            navigate('/');
        } else {
            toast({
                variant: 'destructive',
                title: `Error de ${mode === 'login' ? 'inicio de sesión' : 'registro'}`,
                description: error.message || 'Ocurrió un error. Por favor, inténtalo de nuevo.',
            });
        }
    };

    const switchMode = (newMode) => {
        setMode(newMode);
        setSearchParams({ mode: newMode });
        setEmail('');
        setPassword('');
    };

    return (
        <>
            <Helmet>
                <title>{mode === 'login' ? 'Iniciar Sesión' : 'Registro'} - SolarApp</title>
                <meta name="description" content={`Página de ${mode === 'login' ? 'inicio de sesión' : 'registro'} para SolarApp.`} />
            </Helmet>
            <div className="flex items-center justify-center min-h-[calc(100vh-160px)] p-4">
                <motion.div 
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5 }}
                    className="w-full max-w-md solar-card p-8 rounded-2xl"
                >
                    <div className="text-center mb-8">
                        <div className="solar-gradient p-4 rounded-full w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                            <Sun className="w-8 h-8 text-white" />
                        </div>
                        <h1 className="text-3xl font-bold">{mode === 'login' ? 'Bienvenido de Nuevo' : 'Crea tu Cuenta'}</h1>
                        <p className="text-gray-400">{mode === 'login' ? 'Ingresa para acceder a tus resultados.' : 'Regístrate para guardar y comparar.'}</p>
                    </div>

                    <form onSubmit={handleAuth} className="space-y-6">
                        <div className="relative">
                            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                            <input
                                type="email"
                                placeholder="correo@ejemplo.com"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                                className="w-full p-3 pl-10 rounded-xl bg-white/10 border border-white/20 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                            />
                        </div>
                        <div className="relative">
                            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                            <input
                                type="password"
                                placeholder="Contraseña (mín. 6 caracteres)"
                                value={password}
                                onChange={(e) => setPassword(e.target.value)}
                                required
                                minLength="6"
                                className="w-full p-3 pl-10 rounded-xl bg-white/10 border border-white/20 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-yellow-400"
                            />
                        </div>
                        <Button type="submit" className="w-full solar-gradient text-white font-bold py-3" disabled={loading}>
                            {loading ? (
                                <Loader2 className="w-5 h-5 animate-spin" />
                            ) : (
                                mode === 'login' ? 'Ingresar' : 'Crear Cuenta'
                            )}
                        </Button>
                    </form>

                    <div className="text-center mt-6">
                        <button onClick={() => switchMode(mode === 'login' ? 'register' : 'login')} className="text-sm text-yellow-400 hover:underline">
                            {mode === 'login' ? '¿No tienes cuenta? Crea una ahora' : '¿Ya tienes una cuenta? Inicia sesión'}
                        </button>
                    </div>
                </motion.div>
            </div>
        </>
    );
};

export default AuthPage;