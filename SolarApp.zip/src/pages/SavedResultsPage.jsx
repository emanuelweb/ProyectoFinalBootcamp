import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { supabase } from '@/lib/customSupabaseClient';
import { useAuth } from '@/contexts/SupabaseAuthContext';
import { useNavigate } from 'react-router-dom';
import { Loader2, Trash2, FileText, AlertTriangle, Bookmark } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { toast } from '@/components/ui/use-toast';

const SavedResultsPage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [savedResults, setSavedResults] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      navigate('/auth?mode=login');
      return;
    }

    const fetchSavedResults = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('saved_results')
        .select('*, panels(name, brand, image_url)')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching saved results:', error);
        toast({
          title: "Error al cargar",
          description: "No se pudieron cargar tus resultados guardados.",
          variant: "destructive",
        });
      } else {
        setSavedResults(data);
      }
      setLoading(false);
    };

    fetchSavedResults();
  }, [user, navigate]);

  const handleDelete = async (id) => {
    const { error } = await supabase.from('saved_results').delete().eq('id', id);
    if (error) {
      toast({
        title: "Error al eliminar",
        description: "No se pudo eliminar el resultado.",
        variant: "destructive",
      });
    } else {
      setSavedResults(savedResults.filter(result => result.id !== id));
      toast({
        title: "Resultado eliminado",
        description: "El cálculo ha sido eliminado de tus guardados.",
        variant: "success",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex-grow flex items-center justify-center">
        <Loader2 className="w-12 h-12 animate-spin text-yellow-400" />
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>Mis Resultados Guardados - SolarApp</title>
        <meta name="description" content="Consulta tus cálculos y recomendaciones de paneles solares guardados." />
      </Helmet>
      <div className="container mx-auto px-4 py-12">
        <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
          <h1 className="text-4xl font-bold mb-2">Mis Resultados Guardados</h1>
          <p className="text-lg text-gray-300">Aquí puedes ver todos tus cálculos anteriores.</p>
        </motion.div>

        <AnimatePresence>
          {savedResults.length === 0 ? (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-center py-20 solar-card mt-8 rounded-2xl"
            >
              <Bookmark className="w-20 h-20 mx-auto text-gray-500 mb-4" />
              <h2 className="text-2xl font-semibold mb-2">No tienes resultados guardados</h2>
              <p className="text-gray-400 mb-6">Realiza un cálculo en la página principal y guárdalo para verlo aquí.</p>
              <Button onClick={() => navigate('/')} className="solar-gradient text-white">
                Ir a la Calculadora
              </Button>
            </motion.div>
          ) : (
            <div className="mt-8 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              {savedResults.map((result) => (
                <motion.div
                  key={result.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="solar-card rounded-2xl p-6 flex flex-col"
                >
                  <div className="flex-grow">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <p className="text-xs text-gray-400">Guardado el:</p>
                        <p className="font-semibold">{new Date(result.created_at).toLocaleDateString('es-CO')}</p>
                      </div>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon" className="text-red-400 hover:bg-red-500/10 hover:text-red-300">
                            <Trash2 className="w-5 h-5" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>¿Estás seguro?</AlertDialogTitle>
                            <AlertDialogDescription>
                              Esta acción no se puede deshacer. Esto eliminará permanentemente tu resultado guardado.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction onClick={() => handleDelete(result.id)} className="bg-red-600 hover:bg-red-700">
                              Sí, eliminar
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                    <div className="mb-4">
                      <p className="text-sm text-gray-300">Cálculo para:</p>
                      <p className="text-lg font-bold">{result.user_input.city}, {result.user_input.department}</p>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm mb-4">
                      <div>
                        <p className="text-gray-400">Consumo:</p>
                        <p className="font-semibold">{result.user_input.consumption} kWh</p>
                      </div>
                      <div>
                        <p className="text-gray-400">Área:</p>
                        <p className="font-semibold">{result.user_input.area} m²</p>
                      </div>
                    </div>
                    <div className="bg-black/20 p-4 rounded-lg">
                      <p className="text-sm text-gray-300 mb-2">Panel recomendado:</p>
                      <div className="flex items-center gap-4">
                        <img src={result.panels.image_url} alt={result.panels.name} className="w-16 h-16 rounded-md object-cover" />
                        <div>
                          <p className="font-bold">{result.panels.name}</p>
                          <p className="text-xs text-gray-400">{result.panels.brand}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <Button className="w-full mt-6 solar-gradient text-white" onClick={() => navigate(`/result/${result.id}`)}>
                    <FileText className="w-4 h-4 mr-2" />
                    Ver Detalle Completo
                  </Button>
                </motion.div>
              ))}
            </div>
          )}
        </AnimatePresence>
      </div>
    </>
  );
};

export default SavedResultsPage;