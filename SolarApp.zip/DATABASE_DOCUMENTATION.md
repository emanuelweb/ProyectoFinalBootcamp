# Documentación de la Base de Datos - SolarApp

Este documento describe la estructura de la base de datos utilizada en el proyecto SolarApp, gestionada a través de Supabase (un backend como servicio sobre PostgreSQL).

## Modelo de Entidad-Relación (Resumen)

La base de datos se compone de tres tablas principales que interactúan entre sí:

1.  `departments`: Almacena información sobre los departamentos de Colombia, incluyendo su potencial de radiación solar.
2.  `panels`: Un catálogo de los diferentes paneles solares disponibles, con sus especificaciones técnicas y de mercado.
3.  `saved_results`: Guarda los cálculos realizados por los usuarios registrados, vinculando la entrada del usuario con las recomendaciones generadas.

---

## 1. Tabla `departments`

Esta tabla contiene los datos geográficos y de radiación solar para cada departamento de Colombia.

### Estructura

| Columna           | Tipo de Dato         | Descripción                                                                 |
| ----------------- | -------------------- | --------------------------------------------------------------------------- |
| `id`              | `integer` (PK)       | Identificador único para cada departamento.                                 |
| `name`            | `text`               | Nombre del departamento.                                                    |
| `solar_radiation` | `double precision`   | El valor promedio de radiación solar en kWh/m²/día.                         |
| `level`           | `text`               | Nivel categórico de radiación (e.g., 'Alto', 'Muy Alto').                   |
| `description`     | `text`               | Una breve descripción del potencial solar del departamento (opcional).      |
| `color`           | `text`               | Un código de color hexadecimal para representaciones visuales (e.g., mapas). |

### Consultas Comunes

#### Obtener todos los departamentos

Se utiliza para poblar listas desplegables en formularios y para mostrar el potencial solar en el mapa de la presentación.

```javascript
// En el cliente de Supabase (JavaScript)
import { supabase } from '@/lib/customSupabaseClient';

async function fetchDepartments() {
  const { data, error } = await supabase
    .from('departments')
    .select('*')
    .order('name', { ascending: true });

  if (error) {
    console.error('Error fetching departments:', error);
    return [];
  }
  return data;
}
```

---

## 2. Tabla `panels`

Esta tabla funciona como un catálogo de los paneles solares que la aplicación puede recomendar.

### Estructura

| Columna       | Tipo de Dato       | Descripción                                                              |
| ------------- | ------------------ | ------------------------------------------------------------------------ |
| `id`          | `integer` (PK)     | Identificador único para cada modelo de panel.                           |
| `name`        | `text`             | Nombre comercial del panel.                                              |
| `type`        | `text`             | Tipo de tecnología (e.g., 'Monocristalino', 'Policristalino').           |
| `power`       | `integer`          | Potencia del panel en vatios (W).                                        |
| `efficiency`  | `double precision` | Eficiencia de conversión del panel en porcentaje (%).                    |
| `price`       | `integer`          | Precio unitario del panel en COP.                                        |
| `warranty`    | `integer`          | Años de garantía del producto.                                           |
| `area`        | `double precision` | Área que ocupa un solo panel en metros cuadrados (m²).                   |
| `brand`       | `text`             | Marca o fabricante del panel.                                            |
| `features`    | `jsonb`            | Un array de strings con características destacadas (e.g., `["Alta durabilidad", "Tecnología PERC"]`). |
| `image_url`   | `text`             | URL de la imagen del producto.                                           |

### Consultas Comunes

#### Obtener todos los paneles

Se utiliza al inicio del cálculo para tener todas las opciones disponibles para la comparación.

```javascript
// En el cliente de Supabase (JavaScript)
import { supabase } from '@/lib/customSupabaseClient';

async function fetchPanels() {
  const { data, error } = await supabase
    .from('panels')
    .select('*');

  if (error) {
    console.error('Error fetching panels:', error);
    return [];
  }
  return data;
}
```

---

## 3. Tabla `saved_results`

Esta tabla almacena los resultados de los cálculos que los usuarios deciden guardar. Está protegida por Políticas de Seguridad a Nivel de Fila (RLS) para garantizar que cada usuario solo pueda acceder a sus propios datos.

### Estructura

| Columna             | Tipo de Dato                | Descripción                                                                                             |
| ------------------- | --------------------------- | ------------------------------------------------------------------------------------------------------- |
| `id`                | `uuid` (PK)                 | Identificador único para cada resultado guardado.                                                       |
| `user_id`           | `uuid` (FK a `auth.users`)  | El ID del usuario que guardó el resultado. Vinculado a la tabla de autenticación de Supabase.           |
| `user_input`        | `jsonb`                     | Objeto JSON que almacena los datos ingresados por el usuario (departamento, ciudad, área, consumo).     |
| `recommendations`   | `jsonb`                     | Objeto JSON que contiene el resultado completo del cálculo, incluyendo la lista de paneles recomendados. |
| `selected_panel_id` | `integer` (FK a `panels`)   | El ID del panel que fue marcado como "Recomendado" en el momento del cálculo.                           |
| `created_at`        | `timestamp with time zone`  | Fecha y hora en que se guardó el registro.                                                              |

### Políticas de Seguridad (RLS)

-   **SELECT**: Un usuario solo puede leer (`SELECT`) las filas donde `user_id` coincide con su propio `auth.uid()`.
-   **INSERT**: Un usuario solo puede insertar (`INSERT`) filas si el `user_id` proporcionado es su propio `auth.uid()`.
-   **UPDATE**: Un usuario solo puede actualizar (`UPDATE`) las filas que le pertenecen.
-   **DELETE**: Un usuario solo puede eliminar (`DELETE`) las filas que le pertenecen.

### Consultas Comunes

#### Guardar un nuevo resultado

```javascript
// En el cliente de Supabase (JavaScript)
async function saveResult(userId, userInputData, recommendationsData, panelId) {
  const { data, error } = await supabase
    .from('saved_results')
    .insert({
      user_id: userId,
      user_input: userInputData,
      recommendations: recommendationsData,
      selected_panel_id: panelId,
    });
  // ... manejo de errores
}
```

#### Obtener los resultados guardados de un usuario

```javascript
// En el cliente de Supabase (JavaScript)
async function fetchSavedResults(userId) {
  const { data, error } = await supabase
    .from('saved_results')
    .select('*, panels(name, brand, image_url)') // Incluye datos del panel relacionado
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  // ... manejo de errores
}
```